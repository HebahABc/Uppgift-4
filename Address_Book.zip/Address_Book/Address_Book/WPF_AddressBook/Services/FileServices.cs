﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPF_AddressBook.Models;

namespace WPF_AddressBook.Services
{
    internal class FileServices
    {
        public string GetPath { get; set; } = null!;
        public void SaveFile(string content)
        {
            using var sf = new StreamWriter(GetPath);
            sf.WriteLine(content);
        }

        public string ReadFile()
        {
            try 
            {
                using var sr = new StreamReader(GetPath);
                return sr.ReadToEnd();
            }
            catch
            {
                return null!;
            }
        }

        public void DeleteFile()
        {
            try
            {
                //var data = JsonConvert.DeserializeObject<List<Person>>(GetPath);
                var items = JsonConvert.DeserializeObject<ObservableCollection<Person>>(ReadFile());
                foreach (var item in items)
                {
                    items.Remove(item);

                    /*
                    string[] files = Directory.GetFiles(GetPath);
                    foreach (string file in files)
                    {
                        File.Delete(file);
                    }
                    */
                }
            }
            catch { }
            
        }
    }
}
