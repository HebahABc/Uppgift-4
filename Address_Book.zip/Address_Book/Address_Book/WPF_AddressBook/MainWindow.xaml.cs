﻿using Caliburn.Micro;
using DevExpress.Data.Extensions;
using DevExpress.Utils.CommonDialogs.Internal;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPF_AddressBook.Interfaces;
using WPF_AddressBook.Models;
using WPF_AddressBook.Services;

namespace WPF_AddressBook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private ObservableCollection<Person> people = new ObservableCollection<Person>();
        private readonly FileServices file = new();
        private int listCount;

        public MainWindow()
        {
            InitializeComponent();
            file.GetPath = @$"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\Content.json";
            PopulatePeopleList();

        }

        public void PopulatePeopleList()
        {
            try
            {
                var items = JsonConvert.DeserializeObject<ObservableCollection<Person>>(file.ReadFile());
                if (items != null)
                { people = items; }
            }
            catch { }

            lv_people.ItemsSource = people;
        }

        private void ClearMode()
        {
            tb_firstname.Text = "";
            tb_lastname.Text = "";
            tb_email.Text = "";
            tb_phonenumber.Text = "";
            tb_address.Text = "";
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            Person p = new Person();
            p.FirstName = tb_firstname.Text;
            p.LastName = tb_lastname.Text;
            p.Email = tb_email.Text;
            p.PhoneNumber = tb_phonenumber.Text;
            p.Address = tb_address.Text;
            people.Add(p);
            file.SaveFile(JsonConvert.SerializeObject(people));
            ClearMode();
        }

        private void btn_delete_Click(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)MessageBox.Show("Are you sure you want to delete all contacts?", "Delete all contacts", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == DevExpress.Utils.CommonDialogs.Internal.DialogResult.Yes)
            {
                try
                {
                    for (int i = 0; i <= people.Count; i++)
                    {
                        people.RemoveAt(i);
                        file.SaveFile(JsonConvert.SerializeObject(people));
                        i--;
                    }
                }
                catch { }
            }
        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            Person p = (Person)lv_people.SelectedItem;
            p.FirstName = tb_firstname.Text;
            p.LastName = tb_lastname.Text;
            p.Email = tb_email.Text;
            p.PhoneNumber = tb_phonenumber.Text;
            p.Address = tb_address.Text;
            file.SaveFile(JsonConvert.SerializeObject(people));
        }

        private void btn_deleteOne_Click(object sender, RoutedEventArgs e)
        {
            DialogResult result = (DialogResult)MessageBox.Show("Are you sure you want to delete this contact?", "Delete all contacts", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == DevExpress.Utils.CommonDialogs.Internal.DialogResult.Yes)
            {
                try
                {
                    people.Remove((Person)lv_people.SelectedItem);
                    file.SaveFile(JsonConvert.SerializeObject(people));
                    ClearMode();
                }
                catch { }
            }

        }

        private void lv_people_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
                    Person pr = (Person)lv_people.SelectedItem;
                if (pr != null)
                {
                    tb_firstname.Text = pr.FirstName;
                    tb_lastname.Text = pr.LastName;
                    tb_email.Text = pr.Email;
                    tb_phonenumber.Text = pr.PhoneNumber;
                    tb_address.Text = pr.Address;
                }
                    
                    

            
        }
    }
}
