﻿
using Console_AddressBook.Interfaces;
using Console_AddressBook.Services;

namespace Console_AddressBook.Moduls
{
    internal class Person : IPerson
    {
        public Guid ID { get; set; } = Guid.NewGuid();
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string PhoneNumber { get; set; } = null!;
        public string Address { get; set; } = null!;

        public static explicit operator Person(string v)
        {
            throw new NotImplementedException();
        }
    }
}
