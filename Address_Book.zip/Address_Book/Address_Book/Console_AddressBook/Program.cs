﻿using Console_AddressBook.Interfaces;
using Console_AddressBook.Moduls;
using Console_AddressBook.Services;
using System.Xml.Serialization;

string choice;
MainMenu menu = new MainMenu();
Services serv = new Services();
Console.WriteLine(" Welcome To The Adress Book ");
do
{
    choice = menu.Menu();
    switch (choice)
    {
        case "1":
            {
                Console.Clear();
                Person contact = new Person();
                serv.AddContact(contact);
                break;
            }

        case "2":
            {
                Console.Clear();
                serv.GetAllContacts();
                break;
               
            }

        case "3":
            {
                Console.Clear();
                Console.WriteLine("Write the first name of contact you search for");
                string name = Console.ReadLine();
                //serv.GetContact(name);
                break;
            }

        case "4":
            {
                Console.Clear();
                Console.WriteLine("Enter the first name of the contact you want to remove:");
                string name = Console.ReadLine();
                serv.DeleteContact(name);
                break;
            }

        case "5":
            break;

        default:
            {
                Console.Clear();
                Console.WriteLine("\n You have to choose one of the above options only");
            }
            break;

    }

}
while (choice != "5");
