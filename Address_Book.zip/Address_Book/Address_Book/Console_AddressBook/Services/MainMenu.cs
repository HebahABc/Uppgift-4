﻿

namespace Console_AddressBook.Services
{
    internal class MainMenu
    {
        string s;
        public string Menu() 
        {
            
            Console.WriteLine("\n Main Menu:");
            Console.WriteLine("\n 1. Create a new contact");
            Console.WriteLine("\n 2. View all contacts");
            Console.WriteLine("\n 3. View a specific contact");
            Console.WriteLine("\n 4. Delete a specific contact");
            Console.WriteLine("\n 5. Exit");
            Console.Write("\n Please choose one of the options above: ");
            s = Console.ReadLine();
            return s;
        }

    }
}
