﻿
using Console_AddressBook.Interfaces;
using Console_AddressBook.Moduls;
using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Numerics;
using System.Collections.ObjectModel;
using System.Net.Security;
using System;

namespace Console_AddressBook.Services
{
    internal class Services
    {
        private List<Person> Contacts { get; set; } = new List<Person>();
        private FileService file = new FileService();
        private string filePath = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\ContactList.json";


        public void AddContact(Person p)
        {
            Console.WriteLine("Add Contact:");
            Console.Write("Enter The First Name:");
            p.FirstName = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter The Last Name:");
            p.LastName = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter The Email Address:");
            p.Email = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter The Phone Number:");
            p.PhoneNumber = Console.ReadLine().Trim() ?? "";
            Console.Write("Enter The Adrdress:");
            p.Address = Console.ReadLine().Trim() ?? "";
            Contacts.Add(p);
            file.SaveFile(filePath, JsonConvert.SerializeObject(new { Contacts }));

            Console.Clear();
            Console.Write("The contact has been added successfully!");
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
            /*
            using (str)
            {
                str.WriteLine($"ID: {p.ID}");
                str.WriteLine($"First name: {p.FirstName}");
                str.WriteLine($"Last name: {p.LastName}");
                str.WriteLine($"Email: {p.Email}");
                str.WriteLine($"Phone number: {p.PhoneNumber}");
                str.WriteLine($"Adress: {p.Address}");
                str.WriteLine("=====================");
            }
            */


        }

        public void DeleteContact(string name)
        {
            try
            {
                var items = JsonConvert.DeserializeObject<List<Person>>(file.ReadFile(filePath));
                Person removeP = items.Find(item => item.FirstName.Equals(name));
                if (removeP != null)
                {
                    Contacts.Remove(removeP);
                    file.SaveFile(filePath, JsonConvert.SerializeObject(new { Contacts }));
                    Console.Clear();
                    Console.WriteLine("The contact has been removed successfully!");
                    Console.WriteLine("Press any key to back to the main menu");
                    Console.ReadKey();
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("The requested contact doesn't exist");
                    Console.WriteLine("Press any key to back to the main menu");
                    Console.ReadKey();
                }
            }
            catch { }

        }

      
        public void GetAllContacts()
        {
            try
            {
                Console.WriteLine("Here are all contacts: ");
                var s = file.ReadFile(filePath);
                if (s != null)
                {
                     var items = JsonConvert.DeserializeObject<List<Person>>(s);
                    if (items != null && items.Count > 0)
                        foreach (var item in items)
                        {
                            Console.WriteLine($"First Name: {item.FirstName}");
                            Console.WriteLine($"Lasst Name: {item.LastName}");
                            Console.WriteLine($"Email Address: {item.Email}");
                            Console.WriteLine($"Phone Number: {item.PhoneNumber}");
                            Console.WriteLine($"Address: {item.Address}");
                            Console.WriteLine($"=========================");
                        }

                    else
                    {
                        Console.Clear();
                        Console.WriteLine("There is no contact to view!");
                        Console.WriteLine("Press any key to back to the main menu");
                        Console.ReadKey();
                    }
                    Console.WriteLine("Press any key to back to the main menu");
                    Console.ReadKey();
                }

            }
            catch { }
        }

        

        public void GetContact(string name)
        {

            var s = file.ReadFile(filePath);
            if (s != null)
            {
                var item = JsonConvert.DeserializeObject<List<Person>>(s);
                if (item != null)
                {
                    var findP = Contacts.Find(item => item.FirstName.Equals(name));
                    if (findP != null)
                    {
                        Console.Clear() ;
                        Console.WriteLine("Here is the contact you searched for:");
                        Console.WriteLine($"First Name: {findP.FirstName}");
                        Console.WriteLine($"Last Name: {findP.LastName}");
                        Console.WriteLine($"E-postadress:  {findP.Email}");
                        Console.WriteLine($"Phone Number: {findP.PhoneNumber}");
                        Console.WriteLine($"Adress: {findP.Address}");
                        Console.WriteLine("Press any key to back to the main menu:");
                        Console.ReadKey();
                    }
                    else
                    { Console.WriteLine("The requested contact doesn't exist! "); }
                }
            }
        }
    }
}
    



