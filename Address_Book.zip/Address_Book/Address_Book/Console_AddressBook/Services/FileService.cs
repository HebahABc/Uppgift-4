﻿
namespace Console_AddressBook.Services
{
    internal class FileService
    {
        public void SaveFile(string filePath, string content) 
        {
            using var sf = new StreamWriter(filePath);
            sf.WriteLine(content);
        }

        public string ReadFile(string filePath) 
        {
           try
            {
                using var rf = new StreamReader(filePath);
                return rf.ReadToEnd();
            }
            catch { return null!; }
        }
    }
}
